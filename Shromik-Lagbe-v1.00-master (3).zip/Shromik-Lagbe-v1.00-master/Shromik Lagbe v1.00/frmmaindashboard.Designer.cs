﻿
namespace Shromik_Lagbe_v1._00
{
    partial class frmmaindashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmmaindashboard));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnpayment = new System.Windows.Forms.Button();
            this.btnworker = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnsettings = new System.Windows.Forms.Button();
            this.btnclient = new System.Windows.Forms.Button();
            this.btndashboard = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.username = new System.Windows.Forms.Label();
            this.adminphoto = new System.Windows.Forms.PictureBox();
            this.pnlmainform = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.lbltitle = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.adminphoto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(31)))), ((int)(((byte)(46)))));
            this.panel1.Controls.Add(this.btnpayment);
            this.panel1.Controls.Add(this.btnworker);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.btnsettings);
            this.panel1.Controls.Add(this.btnclient);
            this.panel1.Controls.Add(this.btndashboard);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(190, 561);
            this.panel1.TabIndex = 10;
            // 
            // btnpayment
            // 
            this.btnpayment.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnpayment.FlatAppearance.BorderSize = 0;
            this.btnpayment.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnpayment.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnpayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpayment.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpayment.ForeColor = System.Drawing.Color.White;
            this.btnpayment.Image = ((System.Drawing.Image)(resources.GetObject("btnpayment.Image")));
            this.btnpayment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnpayment.Location = new System.Drawing.Point(0, 275);
            this.btnpayment.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnpayment.Name = "btnpayment";
            this.btnpayment.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnpayment.Size = new System.Drawing.Size(190, 50);
            this.btnpayment.TabIndex = 10;
            this.btnpayment.Text = "PAYMENT";
            this.btnpayment.UseVisualStyleBackColor = true;
            this.btnpayment.Click += new System.EventHandler(this.btnpayment_Click);
            // 
            // btnworker
            // 
            this.btnworker.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnworker.FlatAppearance.BorderSize = 0;
            this.btnworker.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnworker.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnworker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnworker.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnworker.ForeColor = System.Drawing.Color.White;
            this.btnworker.Image = ((System.Drawing.Image)(resources.GetObject("btnworker.Image")));
            this.btnworker.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnworker.Location = new System.Drawing.Point(0, 225);
            this.btnworker.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnworker.Name = "btnworker";
            this.btnworker.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnworker.Size = new System.Drawing.Size(190, 50);
            this.btnworker.TabIndex = 8;
            this.btnworker.Text = "WORKER";
            this.btnworker.UseVisualStyleBackColor = true;
            this.btnworker.Click += new System.EventHandler(this.btnworker_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(0, 124);
            this.panel3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(190, 1);
            this.panel3.TabIndex = 2;
            // 
            // btnsettings
            // 
            this.btnsettings.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnsettings.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnsettings.FlatAppearance.BorderSize = 0;
            this.btnsettings.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SeaGreen;
            this.btnsettings.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SeaGreen;
            this.btnsettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsettings.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsettings.ForeColor = System.Drawing.Color.White;
            this.btnsettings.Image = ((System.Drawing.Image)(resources.GetObject("btnsettings.Image")));
            this.btnsettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsettings.Location = new System.Drawing.Point(0, 511);
            this.btnsettings.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnsettings.Name = "btnsettings";
            this.btnsettings.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnsettings.Size = new System.Drawing.Size(190, 50);
            this.btnsettings.TabIndex = 6;
            this.btnsettings.Text = "SETTINGS";
            this.btnsettings.UseVisualStyleBackColor = false;
            this.btnsettings.Click += new System.EventHandler(this.btnsettings_Click);
            // 
            // btnclient
            // 
            this.btnclient.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnclient.FlatAppearance.BorderSize = 0;
            this.btnclient.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnclient.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnclient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclient.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclient.ForeColor = System.Drawing.Color.White;
            this.btnclient.Image = ((System.Drawing.Image)(resources.GetObject("btnclient.Image")));
            this.btnclient.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnclient.Location = new System.Drawing.Point(0, 175);
            this.btnclient.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnclient.Name = "btnclient";
            this.btnclient.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnclient.Size = new System.Drawing.Size(190, 50);
            this.btnclient.TabIndex = 3;
            this.btnclient.Text = "CLIENT";
            this.btnclient.UseVisualStyleBackColor = true;
            this.btnclient.Click += new System.EventHandler(this.btnclient_Click);
            // 
            // btndashboard
            // 
            this.btndashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.btndashboard.FlatAppearance.BorderSize = 0;
            this.btndashboard.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumSeaGreen;
            this.btndashboard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.btndashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndashboard.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndashboard.ForeColor = System.Drawing.Color.White;
            this.btndashboard.Image = ((System.Drawing.Image)(resources.GetObject("btndashboard.Image")));
            this.btndashboard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndashboard.Location = new System.Drawing.Point(0, 125);
            this.btndashboard.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btndashboard.Size = new System.Drawing.Size(190, 50);
            this.btndashboard.TabIndex = 1;
            this.btndashboard.Text = "DASHBOARD";
            this.btndashboard.UseVisualStyleBackColor = true;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(31)))), ((int)(((byte)(46)))));
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.username);
            this.panel2.Controls.Add(this.adminphoto);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(190, 125);
            this.panel2.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(77, 91);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(20, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.BackColor = System.Drawing.Color.Transparent;
            this.username.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username.ForeColor = System.Drawing.Color.White;
            this.username.Location = new System.Drawing.Point(55, 73);
            this.username.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(71, 17);
            this.username.TabIndex = 1;
            this.username.Text = "username";
            // 
            // adminphoto
            // 
            this.adminphoto.Image = ((System.Drawing.Image)(resources.GetObject("adminphoto.Image")));
            this.adminphoto.Location = new System.Drawing.Point(58, 7);
            this.adminphoto.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.adminphoto.Name = "adminphoto";
            this.adminphoto.Size = new System.Drawing.Size(63, 63);
            this.adminphoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.adminphoto.TabIndex = 0;
            this.adminphoto.TabStop = false;
            // 
            // pnlmainform
            // 
            this.pnlmainform.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlmainform.Location = new System.Drawing.Point(190, 46);
            this.pnlmainform.Name = "pnlmainform";
            this.pnlmainform.Size = new System.Drawing.Size(994, 515);
            this.pnlmainform.TabIndex = 13;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(970, 4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(20, 19);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox6.TabIndex = 12;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.BackColor = System.Drawing.Color.Transparent;
            this.lbltitle.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitle.ForeColor = System.Drawing.Color.White;
            this.lbltitle.Location = new System.Drawing.Point(15, 10);
            this.lbltitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(123, 24);
            this.lbltitle.TabIndex = 11;
            this.lbltitle.Text = "Dashboard";
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.lbltitle);
            this.panel4.Controls.Add(this.pictureBox6);
            this.panel4.Location = new System.Drawing.Point(190, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(994, 45);
            this.panel4.TabIndex = 14;
            // 
            // frmmaindashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(53)))), ((int)(((byte)(79)))));
            this.ClientSize = new System.Drawing.Size(1184, 561);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.pnlmainform);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(31)))), ((int)(((byte)(46)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmmaindashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmmaindashboard";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.adminphoto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnpayment;
        private System.Windows.Forms.Button btnworker;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnsettings;
        private System.Windows.Forms.Button btnclient;
        private System.Windows.Forms.Button btndashboard;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.PictureBox adminphoto;
        private System.Windows.Forms.Panel pnlmainform;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.Panel panel4;
    }
}