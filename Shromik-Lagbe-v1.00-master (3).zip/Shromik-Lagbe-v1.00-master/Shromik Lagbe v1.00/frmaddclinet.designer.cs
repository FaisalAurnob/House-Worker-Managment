﻿
namespace Shromik_Lagbe_v1._00
{
    partial class frmaddclinet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmaddclinet));
            this.label1 = new System.Windows.Forms.Label();
            this.btnresetclient = new System.Windows.Forms.Button();
            this.pnlclientinformation = new System.Windows.Forms.Panel();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.assignid = new System.Windows.Forms.Label();
            this.btnphoto = new System.Windows.Forms.Button();
            this.paymentstatus = new System.Windows.Forms.ComboBox();
            this.servicearea = new System.Windows.Forms.ComboBox();
            this.address = new System.Windows.Forms.TextBox();
            this.phone = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.TextBox();
            this.gender = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.l_name = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.f_name = new System.Windows.Forms.TextBox();
            this.pnlmainpreview = new System.Windows.Forms.Panel();
            this.pnlpreview = new System.Windows.Forms.Panel();
            this.preassignedworkerid = new System.Windows.Forms.Label();
            this.prepayment = new System.Windows.Forms.Label();
            this.preservice = new System.Windows.Forms.Label();
            this.preadd = new System.Windows.Forms.Label();
            this.prephone = new System.Windows.Forms.Label();
            this.preemail = new System.Windows.Forms.Label();
            this.pregender = new System.Windows.Forms.Label();
            this.prename = new System.Windows.Forms.Label();
            this.preclphoto = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btnclientsave = new System.Windows.Forms.Button();
            this.btncancelclient = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.btnpreview = new System.Windows.Forms.Button();
            this.pnlclientinformation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.pnlmainpreview.SuspendLayout();
            this.pnlpreview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.preclphoto)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(192, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "ADD CLIENT INFORMATION";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnresetclient
            // 
            this.btnresetclient.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnresetclient.FlatAppearance.BorderSize = 0;
            this.btnresetclient.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SeaGreen;
            this.btnresetclient.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnresetclient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnresetclient.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnresetclient.ForeColor = System.Drawing.Color.White;
            this.btnresetclient.Location = new System.Drawing.Point(102, 470);
            this.btnresetclient.Name = "btnresetclient";
            this.btnresetclient.Size = new System.Drawing.Size(99, 34);
            this.btnresetclient.TabIndex = 25;
            this.btnresetclient.Text = "RESET";
            this.btnresetclient.UseVisualStyleBackColor = false;
            this.btnresetclient.Click += new System.EventHandler(this.btnresetclient_Click);
            // 
            // pnlclientinformation
            // 
            this.pnlclientinformation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(68)))), ((int)(((byte)(101)))));
            this.pnlclientinformation.Controls.Add(this.numericUpDown1);
            this.pnlclientinformation.Controls.Add(this.assignid);
            this.pnlclientinformation.Controls.Add(this.btnphoto);
            this.pnlclientinformation.Controls.Add(this.paymentstatus);
            this.pnlclientinformation.Controls.Add(this.servicearea);
            this.pnlclientinformation.Controls.Add(this.address);
            this.pnlclientinformation.Controls.Add(this.phone);
            this.pnlclientinformation.Controls.Add(this.email);
            this.pnlclientinformation.Controls.Add(this.gender);
            this.pnlclientinformation.Controls.Add(this.label10);
            this.pnlclientinformation.Controls.Add(this.label9);
            this.pnlclientinformation.Controls.Add(this.label8);
            this.pnlclientinformation.Controls.Add(this.label7);
            this.pnlclientinformation.Controls.Add(this.label6);
            this.pnlclientinformation.Controls.Add(this.label5);
            this.pnlclientinformation.Controls.Add(this.label4);
            this.pnlclientinformation.Controls.Add(this.l_name);
            this.pnlclientinformation.Controls.Add(this.label3);
            this.pnlclientinformation.Controls.Add(this.label2);
            this.pnlclientinformation.Controls.Add(this.f_name);
            this.pnlclientinformation.Location = new System.Drawing.Point(12, 50);
            this.pnlclientinformation.Name = "pnlclientinformation";
            this.pnlclientinformation.Size = new System.Drawing.Size(583, 406);
            this.pnlclientinformation.TabIndex = 1;
            this.pnlclientinformation.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlclientinformation_Paint);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(114)))), ((int)(((byte)(142)))));
            this.numericUpDown1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.numericUpDown1.ForeColor = System.Drawing.Color.White;
            this.numericUpDown1.Location = new System.Drawing.Point(71, 341);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(198, 22);
            this.numericUpDown1.TabIndex = 20;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // assignid
            // 
            this.assignid.AutoSize = true;
            this.assignid.BackColor = System.Drawing.Color.Transparent;
            this.assignid.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.assignid.ForeColor = System.Drawing.Color.White;
            this.assignid.Location = new System.Drawing.Point(67, 310);
            this.assignid.Name = "assignid";
            this.assignid.Size = new System.Drawing.Size(129, 19);
            this.assignid.TabIndex = 19;
            this.assignid.Text = "Assign Worker ID:";
            // 
            // btnphoto
            // 
            this.btnphoto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(114)))), ((int)(((byte)(142)))));
            this.btnphoto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnphoto.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnphoto.ForeColor = System.Drawing.Color.White;
            this.btnphoto.Location = new System.Drawing.Point(308, 332);
            this.btnphoto.Name = "btnphoto";
            this.btnphoto.Size = new System.Drawing.Size(118, 30);
            this.btnphoto.TabIndex = 17;
            this.btnphoto.Text = "Browse...";
            this.btnphoto.UseVisualStyleBackColor = false;
            this.btnphoto.Click += new System.EventHandler(this.btnphoto_Click);
            // 
            // paymentstatus
            // 
            this.paymentstatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(114)))), ((int)(((byte)(142)))));
            this.paymentstatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.paymentstatus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentstatus.ForeColor = System.Drawing.Color.White;
            this.paymentstatus.FormattingEnabled = true;
            this.paymentstatus.Items.AddRange(new object[] {
            "Paid",
            "Unpaid"});
            this.paymentstatus.Location = new System.Drawing.Point(308, 258);
            this.paymentstatus.Name = "paymentstatus";
            this.paymentstatus.Size = new System.Drawing.Size(200, 26);
            this.paymentstatus.TabIndex = 16;
            // 
            // servicearea
            // 
            this.servicearea.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(114)))), ((int)(((byte)(142)))));
            this.servicearea.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.servicearea.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.servicearea.ForeColor = System.Drawing.Color.White;
            this.servicearea.FormattingEnabled = true;
            this.servicearea.Items.AddRange(new object[] {
            "Nikunja 1",
            "Nikunja 2",
            "Khilkhet",
            "Bashundhara"});
            this.servicearea.Location = new System.Drawing.Point(71, 258);
            this.servicearea.Name = "servicearea";
            this.servicearea.Size = new System.Drawing.Size(198, 26);
            this.servicearea.TabIndex = 15;
            // 
            // address
            // 
            this.address.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(114)))), ((int)(((byte)(142)))));
            this.address.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.address.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address.ForeColor = System.Drawing.Color.White;
            this.address.Location = new System.Drawing.Point(308, 190);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(200, 24);
            this.address.TabIndex = 14;
            this.address.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // phone
            // 
            this.phone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(114)))), ((int)(((byte)(142)))));
            this.phone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.phone.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phone.ForeColor = System.Drawing.Color.White;
            this.phone.Location = new System.Drawing.Point(71, 190);
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(198, 24);
            this.phone.TabIndex = 13;
            this.phone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // email
            // 
            this.email.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(114)))), ((int)(((byte)(142)))));
            this.email.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.email.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.White;
            this.email.Location = new System.Drawing.Point(308, 122);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(200, 24);
            this.email.TabIndex = 12;
            this.email.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gender
            // 
            this.gender.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(114)))), ((int)(((byte)(142)))));
            this.gender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gender.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gender.ForeColor = System.Drawing.Color.White;
            this.gender.FormattingEnabled = true;
            this.gender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.gender.Location = new System.Drawing.Point(71, 121);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(198, 26);
            this.gender.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(304, 299);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 19);
            this.label10.TabIndex = 10;
            this.label10.Text = "Upload A Photo:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(304, 226);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 19);
            this.label9.TabIndex = 9;
            this.label9.Text = "Paymnet Status:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(67, 226);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 19);
            this.label8.TabIndex = 8;
            this.label8.Text = "Service Area:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(304, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 19);
            this.label7.TabIndex = 7;
            this.label7.Text = "Address:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(67, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 19);
            this.label6.TabIndex = 6;
            this.label6.Text = "Phone Number:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(304, 88);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 19);
            this.label5.TabIndex = 5;
            this.label5.Text = "Email:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(67, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "Gender:";
            // 
            // l_name
            // 
            this.l_name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(114)))), ((int)(((byte)(142)))));
            this.l_name.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.l_name.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_name.ForeColor = System.Drawing.Color.White;
            this.l_name.Location = new System.Drawing.Point(308, 55);
            this.l_name.Name = "l_name";
            this.l_name.Size = new System.Drawing.Size(200, 24);
            this.l_name.TabIndex = 3;
            this.l_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(304, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Last Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(65, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "First Name:";
            // 
            // f_name
            // 
            this.f_name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(114)))), ((int)(((byte)(142)))));
            this.f_name.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.f_name.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.f_name.ForeColor = System.Drawing.Color.White;
            this.f_name.Location = new System.Drawing.Point(69, 55);
            this.f_name.Name = "f_name";
            this.f_name.Size = new System.Drawing.Size(200, 24);
            this.f_name.TabIndex = 0;
            this.f_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlmainpreview
            // 
            this.pnlmainpreview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(68)))), ((int)(((byte)(101)))));
            this.pnlmainpreview.Controls.Add(this.pnlpreview);
            this.pnlmainpreview.Controls.Add(this.label12);
            this.pnlmainpreview.Location = new System.Drawing.Point(625, 50);
            this.pnlmainpreview.Name = "pnlmainpreview";
            this.pnlmainpreview.Size = new System.Drawing.Size(357, 406);
            this.pnlmainpreview.TabIndex = 26;
            // 
            // pnlpreview
            // 
            this.pnlpreview.Controls.Add(this.preassignedworkerid);
            this.pnlpreview.Controls.Add(this.prepayment);
            this.pnlpreview.Controls.Add(this.preservice);
            this.pnlpreview.Controls.Add(this.preadd);
            this.pnlpreview.Controls.Add(this.prephone);
            this.pnlpreview.Controls.Add(this.preemail);
            this.pnlpreview.Controls.Add(this.pregender);
            this.pnlpreview.Controls.Add(this.prename);
            this.pnlpreview.Controls.Add(this.preclphoto);
            this.pnlpreview.Location = new System.Drawing.Point(14, 12);
            this.pnlpreview.Name = "pnlpreview";
            this.pnlpreview.Size = new System.Drawing.Size(329, 380);
            this.pnlpreview.TabIndex = 0;
            this.pnlpreview.Visible = false;
            // 
            // preassignedworkerid
            // 
            this.preassignedworkerid.AutoSize = true;
            this.preassignedworkerid.BackColor = System.Drawing.Color.Transparent;
            this.preassignedworkerid.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preassignedworkerid.ForeColor = System.Drawing.Color.White;
            this.preassignedworkerid.Location = new System.Drawing.Point(48, 345);
            this.preassignedworkerid.Name = "preassignedworkerid";
            this.preassignedworkerid.Size = new System.Drawing.Size(137, 19);
            this.preassignedworkerid.TabIndex = 46;
            this.preassignedworkerid.Text = "Assigned Worker Id:";
            // 
            // prepayment
            // 
            this.prepayment.AutoSize = true;
            this.prepayment.BackColor = System.Drawing.Color.Transparent;
            this.prepayment.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prepayment.ForeColor = System.Drawing.Color.White;
            this.prepayment.Location = new System.Drawing.Point(48, 314);
            this.prepayment.Name = "prepayment";
            this.prepayment.Size = new System.Drawing.Size(113, 19);
            this.prepayment.TabIndex = 45;
            this.prepayment.Text = "Payment Status:";
            // 
            // preservice
            // 
            this.preservice.AutoSize = true;
            this.preservice.BackColor = System.Drawing.Color.Transparent;
            this.preservice.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preservice.ForeColor = System.Drawing.Color.White;
            this.preservice.Location = new System.Drawing.Point(48, 282);
            this.preservice.Name = "preservice";
            this.preservice.Size = new System.Drawing.Size(93, 19);
            this.preservice.TabIndex = 44;
            this.preservice.Text = "Service Area:";
            // 
            // preadd
            // 
            this.preadd.AutoSize = true;
            this.preadd.BackColor = System.Drawing.Color.Transparent;
            this.preadd.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preadd.ForeColor = System.Drawing.Color.White;
            this.preadd.Location = new System.Drawing.Point(48, 249);
            this.preadd.Name = "preadd";
            this.preadd.Size = new System.Drawing.Size(65, 19);
            this.preadd.TabIndex = 43;
            this.preadd.Text = "Address:";
            // 
            // prephone
            // 
            this.prephone.AutoSize = true;
            this.prephone.BackColor = System.Drawing.Color.Transparent;
            this.prephone.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prephone.ForeColor = System.Drawing.Color.White;
            this.prephone.Location = new System.Drawing.Point(48, 215);
            this.prephone.Name = "prephone";
            this.prephone.Size = new System.Drawing.Size(53, 19);
            this.prephone.TabIndex = 42;
            this.prephone.Text = "Phone:";
            // 
            // preemail
            // 
            this.preemail.AutoSize = true;
            this.preemail.BackColor = System.Drawing.Color.Transparent;
            this.preemail.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preemail.ForeColor = System.Drawing.Color.White;
            this.preemail.Location = new System.Drawing.Point(48, 179);
            this.preemail.Name = "preemail";
            this.preemail.Size = new System.Drawing.Size(49, 19);
            this.preemail.TabIndex = 41;
            this.preemail.Text = "Email:";
            // 
            // pregender
            // 
            this.pregender.AutoSize = true;
            this.pregender.BackColor = System.Drawing.Color.Transparent;
            this.pregender.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pregender.ForeColor = System.Drawing.Color.White;
            this.pregender.Location = new System.Drawing.Point(48, 144);
            this.pregender.Name = "pregender";
            this.pregender.Size = new System.Drawing.Size(60, 19);
            this.pregender.TabIndex = 40;
            this.pregender.Text = "Gender:";
            // 
            // prename
            // 
            this.prename.AutoSize = true;
            this.prename.BackColor = System.Drawing.Color.Transparent;
            this.prename.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prename.ForeColor = System.Drawing.Color.White;
            this.prename.Location = new System.Drawing.Point(48, 109);
            this.prename.Name = "prename";
            this.prename.Size = new System.Drawing.Size(51, 19);
            this.prename.TabIndex = 39;
            this.prename.Text = "Name:";
            // 
            // preclphoto
            // 
            this.preclphoto.ErrorImage = ((System.Drawing.Image)(resources.GetObject("preclphoto.ErrorImage")));
            this.preclphoto.Image = ((System.Drawing.Image)(resources.GetObject("preclphoto.Image")));
            this.preclphoto.Location = new System.Drawing.Point(131, 12);
            this.preclphoto.Name = "preclphoto";
            this.preclphoto.Size = new System.Drawing.Size(80, 80);
            this.preclphoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.preclphoto.TabIndex = 38;
            this.preclphoto.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(78, 183);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(186, 17);
            this.label12.TabIndex = 30;
            this.label12.Text = "Preview Will Be Load Here...";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnclientsave
            // 
            this.btnclientsave.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnclientsave.FlatAppearance.BorderSize = 0;
            this.btnclientsave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SeaGreen;
            this.btnclientsave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnclientsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclientsave.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclientsave.ForeColor = System.Drawing.Color.White;
            this.btnclientsave.Location = new System.Drawing.Point(771, 470);
            this.btnclientsave.Name = "btnclientsave";
            this.btnclientsave.Size = new System.Drawing.Size(99, 34);
            this.btnclientsave.TabIndex = 27;
            this.btnclientsave.Text = "SAVE";
            this.btnclientsave.UseVisualStyleBackColor = false;
            this.btnclientsave.Visible = false;
            this.btnclientsave.Click += new System.EventHandler(this.btnclientsave_Click);
            // 
            // btncancelclient
            // 
            this.btncancelclient.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btncancelclient.FlatAppearance.BorderSize = 0;
            this.btncancelclient.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SeaGreen;
            this.btncancelclient.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.btncancelclient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncancelclient.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancelclient.ForeColor = System.Drawing.Color.White;
            this.btncancelclient.Location = new System.Drawing.Point(390, 470);
            this.btncancelclient.Name = "btncancelclient";
            this.btncancelclient.Size = new System.Drawing.Size(99, 34);
            this.btncancelclient.TabIndex = 28;
            this.btncancelclient.Text = "BACK";
            this.btncancelclient.UseVisualStyleBackColor = false;
            this.btncancelclient.Click += new System.EventHandler(this.btncancelclient_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(768, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 17);
            this.label11.TabIndex = 29;
            this.label11.Text = "PREVIEW";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnpreview
            // 
            this.btnpreview.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnpreview.FlatAppearance.BorderSize = 0;
            this.btnpreview.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SeaGreen;
            this.btnpreview.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnpreview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpreview.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpreview.ForeColor = System.Drawing.Color.White;
            this.btnpreview.Location = new System.Drawing.Point(245, 470);
            this.btnpreview.Name = "btnpreview";
            this.btnpreview.Size = new System.Drawing.Size(99, 34);
            this.btnpreview.TabIndex = 30;
            this.btnpreview.Text = "PREVIEW";
            this.btnpreview.UseVisualStyleBackColor = false;
            this.btnpreview.Click += new System.EventHandler(this.btnpreview_Click);
            // 
            // frmaddclinet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(53)))), ((int)(((byte)(79)))));
            this.ClientSize = new System.Drawing.Size(995, 517);
            this.Controls.Add(this.btnpreview);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btncancelclient);
            this.Controls.Add(this.btnclientsave);
            this.Controls.Add(this.pnlmainpreview);
            this.Controls.Add(this.btnresetclient);
            this.Controls.Add(this.pnlclientinformation);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmaddclinet";
            this.Text = "addclient";
            this.pnlclientinformation.ResumeLayout(false);
            this.pnlclientinformation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.pnlmainpreview.ResumeLayout(false);
            this.pnlmainpreview.PerformLayout();
            this.pnlpreview.ResumeLayout(false);
            this.pnlpreview.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.preclphoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnresetclient;
        private System.Windows.Forms.Panel pnlclientinformation;
        private System.Windows.Forms.Panel pnlmainpreview;
        private System.Windows.Forms.Button btnclientsave;
        private System.Windows.Forms.Button btncancelclient;
        private System.Windows.Forms.ComboBox paymentstatus;
        private System.Windows.Forms.ComboBox servicearea;
        private System.Windows.Forms.TextBox address;
        private System.Windows.Forms.TextBox phone;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.ComboBox gender;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox l_name;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox f_name;
        private System.Windows.Forms.Button btnphoto;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel pnlpreview;
        private System.Windows.Forms.Label prepayment;
        private System.Windows.Forms.Label preservice;
        private System.Windows.Forms.Label preadd;
        private System.Windows.Forms.Label prephone;
        private System.Windows.Forms.Label preemail;
        private System.Windows.Forms.Label pregender;
        private System.Windows.Forms.Label prename;
        private System.Windows.Forms.PictureBox preclphoto;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label assignid;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label preassignedworkerid;
        private System.Windows.Forms.Button btnpreview;
    }
}